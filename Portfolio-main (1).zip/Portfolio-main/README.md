<<<<<<< HEAD
# Portfolio
=======
# 🎨 Creative Portfolio Website

A modern, interactive portfolio website with a sleek dark theme and creative UI/UX designs.

## ✨ Features

- **Dark Theme** - Modern dark background with cyberpunk-inspired gradient colors
- **Responsive Design** - Fully responsive on all devices (mobile, tablet, desktop)
- **Smooth Animations** - Scroll-triggered animations and interactive effects
- **Multiple Sections**:
  - Hero section with call-to-action buttons
  - About me with profile photo and social links
  - Education timeline
  - Projects showcase with GitHub and live demo links
  - Technical skills with category icons
  - Achievements section
  - Contact information
- **Interactive Elements**:
  - Smooth scrolling navigation
  - Hover effects on cards
  - Ripple effect on buttons
  - Counter animations for stats
  - Dynamic role text rotation

# 🎨 Creative Portfolio Website

A modern, interactive portfolio website with a sleek dark theme and creative UI/UX designs.

## ✨ Features

- **Dark Theme** - Modern dark background with cyberpunk-inspired gradient colors
- **Responsive Design** - Fully responsive on all devices (mobile, tablet, desktop)
- **Smooth Animations** - Scroll-triggered animations and interactive effects
- **Multiple Sections**:
  - Hero section with call-to-action buttons
  - About me with profile photo and social links
  - Education timeline
  - Projects showcase with GitHub and live demo links
  - Technical skills with category icons
  - Achievements section
  - Contact information
- **Interactive Elements**:
  - Smooth scrolling navigation
  - Hover effects on cards
  - Ripple effect on buttons
  - Counter animations for stats
  - Dynamic role text rotation

## 🛠️ Technologies Used

- **HTML5** - Semantic markup
- **CSS3** - Advanced styling with gradients, animations, and flexbox/grid
- **JavaScript** - Interactivity and smooth animations
- **Font Awesome Icons** - Beautiful icons for skills and social links
- **Placeholders** - Placeholder images for profile and projects

## 📁 Files

- `index.html` - Main HTML structure
- `styles.css` - All styling and animations
- `script.js` - JavaScript for interactivity
- `README.md` - This file

## 💡 Tips for Best Results

1. **Profile Photo**: Use a high-quality, professional headshot
2. **Project Images**: Use consistent dimensions (recommended 400x250px)
3. **Content**: Keep descriptions concise and engaging
4. **Links**: Ensure all GitHub and demo links are correct
5. **Testing**: Test on different devices to ensure responsiveness

## 📝 Notes

- The portfolio uses Font Awesome 6.4.0 via CDN
- Placeholder images are from Placeholder.com
- All animations are CSS-based for better performance
- The design follows modern UI/UX principles

## 🚀 Deployment

To host this portfolio:

1. **GitHub Pages**:
   - Create a GitHub repository
   - Push your files
   - Enable Pages in repository settings

2. **Netlify**:
   - Connect your GitHub repository
   - Netlify will auto-deploy on every push

3. **Vercel**:
   - Import your repository
   - One-click deployment

4. **Traditional Hosting**:
   - Upload files via FTP
   - Ensure all paths are correct

## 📞 Quick Links to Update

- [ ] Update "Your Name" in hero section
- [ ] Replace profile photo
- [ ] Update social media links
- [ ] Add education details
- [ ] Add 3-6 projects with images
- [ ] Update technical skills
- [ ] Add achievements
- [ ] Update contact information
- [ ] Test on mobile devices
- [ ] Deploy to hosting platform

## 🎉 You're All Set!

Your creative portfolio is ready to impress! Customize it with your information and share it with the world.

---

**Happy coding! 🚀**
